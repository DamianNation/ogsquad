﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TypewriterScript : MonoBehaviour
{

    public float delay = 0.1f;
    public string  fullText;
    private string currentText = "";

    // Use this for initialization
    void Start()
    {
        StartCoroutine(ShowText());

    }

    IEnumerator ShowText() //Create a timer to start text and how much count and delay
    {
        for (int i = 0; i < fullText.Length; i++) //Find length of strings
        {
            currentText = fullText.Substring(0,i); //start at first letter
            this.GetComponent<Text>().text = currentText; //using U0 element
            yield return new WaitForSeconds(delay); //begin delay
        }
    }
    

    
}
